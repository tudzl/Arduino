   

# fusiontest.py Simple test program for sensor fusion on Pyboard

# Author Peter Hinch

# Released under the MIT License (MIT)

# Copyright (c) 2017 Peter Hinch

# V0.8 14th May 2017 Option for external switch for cal test. Make platform independent.

# V0.7 25th June 2015 Adapted for new MPU9x50 interface
from m5ui import *

from m5stack import lcd

from machine import Pin

import utime as time

#from mpu9250 import MPU9250
import imu

#from fusion import Fusion

from machine import I2C

import time

from math import sqrt, atan2, asin, degrees, radians

import gc
#i2c = I2C(sda = 21, scl = 22)





#----------------------Fusion-------------------------
def elapsed_micros(start_time):

    # return time.ticks_us() - start_time

    return time.ticks_diff(time.ticks_us(), start_time)



class Fusion(object):

    '''

    Class provides sensor fusion allowing heading, pitch and roll to be extracted. This uses the Madgwick algorithm.

    The update method must be called peiodically. The calculations take 1.6mS on the Pyboard.

    '''

    declination = 0                         # Optional offset for true north. A +ve value adds to heading

    def __init__(self):

        self.magbias = (0, 0, 0)            # local magnetic bias factors: set from calibration

        self.start_time = None              # Time between updates

        self.q = [1.0, 0.0, 0.0, 0.0]       # vector to hold quaternion

        GyroMeasError = radians(40)         # Original code indicates this leads to a 2 sec response time

        self.beta = sqrt(3.0 / 4.0) * GyroMeasError  # compute beta (see README)

        self.pitch = 0

        self.heading = 0

        self.roll = 0



    def calibrate(self, getxyz, stopfunc, wait=0):

        magmax = list(getxyz())             # Initialise max and min lists with current values

        magmin = magmax[:]
        
        #while not stopfunc():
        while not btnB.isPressed():

            if wait != 0:

                if callable(wait):

                    wait()

                else:

                    time.sleep_ms(wait)

            magxyz = tuple(getxyz())

            for x in range(3):

                magmax[x] = max(magmax[x], magxyz[x])

                magmin[x] = min(magmin[x], magxyz[x])

        self.magbias = tuple(map(lambda a, b: (a +b)/2, magmin, magmax))



    def update_nomag(self, accel, gyro):    # 3-tuples (x, y, z) for accel, gyro

        ax, ay, az = accel                  # Units G (but later normalised)

        gx, gy, gz = (radians(x) for x in gyro) # Units deg/s

        if self.start_time is None:

            self.start_time = time.ticks_us()  # First run

        q1, q2, q3, q4 = (self.q[x] for x in range(4))   # short name local variable for readability

        # Auxiliary variables to avoid repeated arithmetic

        _2q1 = 2 * q1

        _2q2 = 2 * q2

        _2q3 = 2 * q3

        _2q4 = 2 * q4

        _4q1 = 4 * q1

        _4q2 = 4 * q2

        _4q3 = 4 * q3

        _8q2 = 8 * q2

        _8q3 = 8 * q3

        q1q1 = q1 * q1

        q2q2 = q2 * q2

        q3q3 = q3 * q3

        q4q4 = q4 * q4



        # Normalise accelerometer measurement

        norm = sqrt(ax * ax + ay * ay + az * az)

        if (norm == 0):

            return # handle NaN

        norm = 1 / norm        # use reciprocal for division

        ax *= norm

        ay *= norm

        az *= norm



        # Gradient decent algorithm corrective step

        s1 = _4q1 * q3q3 + _2q3 * ax + _4q1 * q2q2 - _2q2 * ay

        s2 = _4q2 * q4q4 - _2q4 * ax + 4 * q1q1 * q2 - _2q1 * ay - _4q2 + _8q2 * q2q2 + _8q2 * q3q3 + _4q2 * az

        s3 = 4 * q1q1 * q3 + _2q1 * ax + _4q3 * q4q4 - _2q4 * ay - _4q3 + _8q3 * q2q2 + _8q3 * q3q3 + _4q3 * az

        s4 = 4 * q2q2 * q4 - _2q2 * ax + 4 * q3q3 * q4 - _2q3 * ay

        norm = 1 / sqrt(s1 * s1 + s2 * s2 + s3 * s3 + s4 * s4)    # normalise step magnitude

        s1 *= norm

        s2 *= norm

        s3 *= norm

        s4 *= norm



        # Compute rate of change of quaternion

        qDot1 = 0.5 * (-q2 * gx - q3 * gy - q4 * gz) - self.beta * s1

        qDot2 = 0.5 * (q1 * gx + q3 * gz - q4 * gy) - self.beta * s2

        qDot3 = 0.5 * (q1 * gy - q2 * gz + q4 * gx) - self.beta * s3

        qDot4 = 0.5 * (q1 * gz + q2 * gy - q3 * gx) - self.beta * s4



        # Integrate to yield quaternion

        deltat = elapsed_micros(self.start_time) / 1000000

        self.start_time = time.ticks_us()

        q1 += qDot1 * deltat

        q2 += qDot2 * deltat

        q3 += qDot3 * deltat

        q4 += qDot4 * deltat

        norm = 1 / sqrt(q1 * q1 + q2 * q2 + q3 * q3 + q4 * q4)    # normalise quaternion

        self.q = q1 * norm, q2 * norm, q3 * norm, q4 * norm

        self.heading = 0

        self.pitch = degrees(-asin(2.0 * (self.q[1] * self.q[3] - self.q[0] * self.q[2])))

        self.roll = degrees(atan2(2.0 * (self.q[0] * self.q[1] + self.q[2] * self.q[3]),

            self.q[0] * self.q[0] - self.q[1] * self.q[1] - self.q[2] * self.q[2] + self.q[3] * self.q[3]))



    def update(self, accel, gyro, mag):     # 3-tuples (x, y, z) for accel, gyro and mag data

        mx, my, mz = (mag[x] - self.magbias[x] for x in range(3)) # Units irrelevant (normalised)

        ax, ay, az = accel                  # Units irrelevant (normalised)

        gx, gy, gz = (radians(x) for x in gyro)  # Units deg/s

        if self.start_time is None:

            self.start_time = time.ticks_us()  # First run

        q1, q2, q3, q4 = (self.q[x] for x in range(4))   # short name local variable for readability

        # Auxiliary variables to avoid repeated arithmetic

        _2q1 = 2 * q1

        _2q2 = 2 * q2

        _2q3 = 2 * q3

        _2q4 = 2 * q4

        _2q1q3 = 2 * q1 * q3

        _2q3q4 = 2 * q3 * q4

        q1q1 = q1 * q1

        q1q2 = q1 * q2

        q1q3 = q1 * q3

        q1q4 = q1 * q4

        q2q2 = q2 * q2

        q2q3 = q2 * q3

        q2q4 = q2 * q4

        q3q3 = q3 * q3

        q3q4 = q3 * q4

        q4q4 = q4 * q4



        # Normalise accelerometer measurement

        norm = sqrt(ax * ax + ay * ay + az * az)

        if (norm == 0):

            return # handle NaN

        norm = 1 / norm                     # use reciprocal for division

        ax *= norm

        ay *= norm

        az *= norm



        # Normalise magnetometer measurement

        norm = sqrt(mx * mx + my * my + mz * mz)

        if (norm == 0):

            return                          # handle NaN

        norm = 1 / norm                     # use reciprocal for division

        mx *= norm

        my *= norm

        mz *= norm



        # Reference direction of Earth's magnetic field

        _2q1mx = 2 * q1 * mx

        _2q1my = 2 * q1 * my

        _2q1mz = 2 * q1 * mz

        _2q2mx = 2 * q2 * mx

        hx = mx * q1q1 - _2q1my * q4 + _2q1mz * q3 + mx * q2q2 + _2q2 * my * q3 + _2q2 * mz * q4 - mx * q3q3 - mx * q4q4

        hy = _2q1mx * q4 + my * q1q1 - _2q1mz * q2 + _2q2mx * q3 - my * q2q2 + my * q3q3 + _2q3 * mz * q4 - my * q4q4

        _2bx = sqrt(hx * hx + hy * hy)

        _2bz = -_2q1mx * q3 + _2q1my * q2 + mz * q1q1 + _2q2mx * q4 - mz * q2q2 + _2q3 * my * q4 - mz * q3q3 + mz * q4q4

        _4bx = 2 * _2bx

        _4bz = 2 * _2bz



        # Gradient descent algorithm corrective step

        s1 = (-_2q3 * (2 * q2q4 - _2q1q3 - ax) + _2q2 * (2 * q1q2 + _2q3q4 - ay) - _2bz * q3 * (_2bx * (0.5 - q3q3 - q4q4)

             + _2bz * (q2q4 - q1q3) - mx) + (-_2bx * q4 + _2bz * q2) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my)

             + _2bx * q3 * (_2bx * (q1q3 + q2q4) + _2bz * (0.5 - q2q2 - q3q3) - mz))



        s2 = (_2q4 * (2 * q2q4 - _2q1q3 - ax) + _2q1 * (2 * q1q2 + _2q3q4 - ay) - 4 * q2 * (1 - 2 * q2q2 - 2 * q3q3 - az)

             + _2bz * q4 * (_2bx * (0.5 - q3q3 - q4q4) + _2bz * (q2q4 - q1q3) - mx) + (_2bx * q3 + _2bz * q1) * (_2bx * (q2q3 - q1q4)

             + _2bz * (q1q2 + q3q4) - my) + (_2bx * q4 - _4bz * q2) * (_2bx * (q1q3 + q2q4) + _2bz * (0.5 - q2q2 - q3q3) - mz))



        s3 = (-_2q1 * (2 * q2q4 - _2q1q3 - ax) + _2q4 * (2 * q1q2 + _2q3q4 - ay) - 4 * q3 * (1 - 2 * q2q2 - 2 * q3q3 - az)

             + (-_4bx * q3 - _2bz * q1) * (_2bx * (0.5 - q3q3 - q4q4) + _2bz * (q2q4 - q1q3) - mx)

             + (_2bx * q2 + _2bz * q4) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my)

             + (_2bx * q1 - _4bz * q3) * (_2bx * (q1q3 + q2q4) + _2bz * (0.5 - q2q2 - q3q3) - mz))



        s4 = (_2q2 * (2 * q2q4 - _2q1q3 - ax) + _2q3 * (2 * q1q2 + _2q3q4 - ay) + (-_4bx * q4 + _2bz * q2) * (_2bx * (0.5 - q3q3 - q4q4)

              + _2bz * (q2q4 - q1q3) - mx) + (-_2bx * q1 + _2bz * q3) * (_2bx * (q2q3 - q1q4) + _2bz * (q1q2 + q3q4) - my)

              + _2bx * q2 * (_2bx * (q1q3 + q2q4) + _2bz * (0.5 - q2q2 - q3q3) - mz))



        norm = 1 / sqrt(s1 * s1 + s2 * s2 + s3 * s3 + s4 * s4)    # normalise step magnitude

        s1 *= norm

        s2 *= norm

        s3 *= norm

        s4 *= norm



        # Compute rate of change of quaternion

        qDot1 = 0.5 * (-q2 * gx - q3 * gy - q4 * gz) - self.beta * s1

        qDot2 = 0.5 * (q1 * gx + q3 * gz - q4 * gy) - self.beta * s2

        qDot3 = 0.5 * (q1 * gy - q2 * gz + q4 * gx) - self.beta * s3

        qDot4 = 0.5 * (q1 * gz + q2 * gy - q3 * gx) - self.beta * s4



        # Integrate to yield quaternion

        deltat = elapsed_micros(self.start_time) / 1000000

        self.start_time = time.ticks_us()

        q1 += qDot1 * deltat

        q2 += qDot2 * deltat

        q3 += qDot3 * deltat

        q4 += qDot4 * deltat

        norm = 1 / sqrt(q1 * q1 + q2 * q2 + q3 * q3 + q4 * q4)    # normalise quaternion

        self.q = q1 * norm, q2 * norm, q3 * norm, q4 * norm

        self.heading = self.declination + degrees(atan2(2.0 * (self.q[1] * self.q[2] + self.q[0] * self.q[3]),

            self.q[0] * self.q[0] + self.q[1] * self.q[1] - self.q[2] * self.q[2] - self.q[3] * self.q[3]))

        self.pitch = degrees(-asin(2.0 * (self.q[1] * self.q[3] - self.q[0] * self.q[2])))

        self.roll = degrees(atan2(2.0 * (self.q[0] * self.q[1] + self.q[2] * self.q[3]),

            self.q[0] * self.q[0] - self.q[1] * self.q[1] - self.q[2] * self.q[2] + self.q[3] * self.q[3]))
			

#-----------------------------end fusion-----------------------------------



def getmag():                               # Return (x, y, z) tuple (blocking read)

    #return imu.mag.xyz
    return imu.ypr
#---------------main code starts here
imu = imu.IMU()

fuse = Fusion()

if btnA.isPressed():
    speaker.tone(346, 120, 1)
    print("Calibrating. Press switch when done.")

    fuse.calibrate(getmag, 0, lambda : time.sleep(0.1))
    #fuse.calibrate(getmag, btnB.press, lambda : time.sleep(0.1))
    print(fuse.magbias)


# for test only
if True:

    mag = imu.ypr   # modified by zl
    #mag = imu.magnetic # Don't include blocking read in time

    accel = imu.acceleration # or i2c

    gyro = imu.gyro

    start = time.ticks_us()  # Measure computation time only

    fuse.update(accel, gyro, mag) # 1.97mS on Pyboard

    t = time.ticks_diff(time.ticks_us(), start)

    print("Update time (uS):", t)
    lcd.setTextColor(lcd.YELLOW, lcd.BLACK)
    lcd.print("Update time (uS):", t, lcd.CENTER, 160)
    time.sleep_ms(800)




lcd.clear()
title = M5Title(title="         Mpu9250 demo  2019.7", x=3 , fgcolor=0xff9900, bgcolor=0x1F1FAF)
lcd.font(lcd.FONT_Small)
lcd.setBrightness(25)
lcd.setTextColor(lcd.WHITE, lcd.BLACK)
label_cnt = M5TextBox(220, 225, "CNT: ", lcd.FONT_Default,0xFFEEBB, rotate=0)
count = 0

run_cnt = 0

while True:
  #Calibrate  have bugs!!!
  if btnA.isPressed():
    #speaker.tone(346, 120, 1)
    wait(0.1)
    print("Calibrating. Press switch when done.")
    lcd.print("Calibrating. Press switch B when done.", lcd.CENTER, 160)
    fuse.calibrate(getmag, 0, lambda : time.sleep(0.1))
    #fuse.calibrate(getmag, btnB.press, lambda : time.sleep(0.1))
    lcd.print("Calib. magbias:", fuse.magbias, lcd.CENTER, 180)
    print(fuse.magbias)
    gc.collect()

  while not btnA.isPressed():
  
    accel = imu.acceleration

    gyro = imu.gyro

    #mag = imu.magnetic
    mag = imu.ypr  # modified by zl

    fuse.update(accel, gyro, mag) # Note blocking mag read



    print("         Heading      Pitch       Roll:")

    print("        {:8.3f}   {:8.3f}   {:8.3f}".format(fuse.heading, fuse.pitch, fuse.roll))

    print("ACCEL:  {:8.3f}   {:8.3f}   {:8.3f}".format(accel[0], accel[1], accel[2]))

    print("GYRO:   {:8.3f}   {:8.3f}   {:8.3f}".format(gyro[0], gyro[1], gyro[2]))

    print("MAG:    {:8.3f}   {:8.3f}   {:8.3f}\n".format(mag[0], mag[1], mag[2]))


    lcd.setTextColor(lcd.WHITE, lcd.BLACK)
    lcd.print("ACCEL: {:+7.2f}  {:+7.2f}  {:+7.2f}".format(accel[0], accel[1], accel[2]), lcd.CENTER, 20)
    #lcd.setTextColor(lcd.GRAY, lcd.BLACK)
    lcd.print("GYRO:  {:+7.2f}  {:+7.2f}  {:+7.2f}".format(gyro[0], gyro[1], gyro[2]), lcd.CENTER, 40)

    lcd.print("MAG:   {:+7.2f}  {:+7.2f}  {:+7.2f}".format(mag[0], mag[1], mag[2]), lcd.CENTER, 60)

    lcd.setTextColor(lcd.ORANGE, lcd.BLACK)

    lcd.print("Heading      Pitch      Roll", lcd.CENTER, 120)
    lcd.setTextColor(lcd.BLUE, lcd.BLACK)
    lcd.print("{:+7.2f}    {:+7.2f}    {:+7.2f}".format(fuse.heading, fuse.pitch, fuse.roll), lcd.CENTER, 137)

    run_cnt = run_cnt+1
    label_cnt.setText("Run: "+str(run_cnt) )
    gc.collect()
    time.sleep_ms(10)